const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

// Use CORS middleware
app.use(cors());
app.use(express.json()); // Middleware to parse JSON

app.use(cors({ origin: '*' }));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/centralizedSystem', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("Connected to MongoDB");
}).catch(err => {
    console.error("MongoDB connection error:", err.message);
});

// User Schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

// User Model
const User = mongoose.model('User', userSchema); // Ensure this is defined before usage

// Array to keep track of connected users
let connectedUsers = [];

// Registration Route
app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    // Hash the password before saving
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
        const newUser = new User({ username, password: hashedPassword });
        await newUser.save();
        res.status(201).send('User registered successfully');
    } catch (error) {
        console.error("Error during registration:", error); // Log the error for debugging
        res.status(500).send('Error registering user: ' + error.message);
    }
});

// Login Route
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(401).send('Invalid username or password');
        }

        // Compare the hashed password with the provided password
        const isMatch = await bcrypt.compare(password, user.password);
        if (isMatch) {
            // Add user to connectedUsers array
            if (!connectedUsers.includes(username)) {
                connectedUsers.push(username);
            }
            res.status(200).send('Login successful');
        } else {
            res.status(401).send('Invalid username or password');
        }
    } catch (error) {
        console.error("Error during login:", error);
        res.status(500).send('Error logging in: ' + error.message);
    }
});

// Endpoint to get the list of connected users
app.get('/users', (req, res) => {
    res.json(connectedUsers); // Return the list of connected users
});

const path = require('path');

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});


// Endpoint to remove user from the connected users list
app.post('/logout', (req, res) => {
    const { username } = req.body;
    connectedUsers = connectedUsers.filter(user => user !== username);
    res.sendStatus(200);
});

app.use(express.static(path.join(__dirname)));


// Start the server
app.listen(PORT, () => {
    console.log('Server is running on http://localhost:${PORT}');
});

app.listen(3000, '0.0.0.0');

